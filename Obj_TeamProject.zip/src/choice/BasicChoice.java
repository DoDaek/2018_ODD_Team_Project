package choice;

public interface BasicChoice {

	public void MakingChoice(String input);

	public void MakingChoice_2(String input);
}