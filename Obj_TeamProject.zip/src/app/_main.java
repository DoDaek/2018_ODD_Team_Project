package app;

public class _main {
	public static void main(String[] args) {
		AppController appController = new AppController();
		appController.Run();
	}
}